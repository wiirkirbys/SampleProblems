using UnityEngine;

[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/MovingObjectData", order = 1)]
public class MovingObjectData : ScriptableObject
{
    public Vector3 initialLocation;
    public Vector3 location;
    public Quaternion initialDirection;
    public Quaternion direction;
    public float initialSpeed;
    public float speed;
}