using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoveUI : MonoBehaviour
{
    public GameObject moveObjects;

    [SerializeField]
    private Text pauseButtonText;
    [SerializeField]
    private Text objectDataText;

    private bool isPaused;
    // Start is called before the first frame update
    void Start()
    {
        isPaused = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit))
            {
                objectDataText.text = "Speed: " + hit.collider.gameObject.GetComponent<MovingObject>().data.speed +
                    " Rotation: " + hit.collider.gameObject.GetComponent<MovingObject>().data.direction;
            }
        }
    }

    public void Pause()
    {
       for(int i = 0; i < 3; i++)
        {
            if(isPaused)
            {
                moveObjects.transform.GetChild(i).gameObject.GetComponent<MovingObject>().Resume();
                pauseButtonText.text = "Pause";

            }
            else
            {
                moveObjects.transform.GetChild(i).gameObject.GetComponent<MovingObject>().Pause();
                pauseButtonText.text = "Resume";
            }
        }
        isPaused = !isPaused;
    }
    public void Reset()
    {
        for (int i = 0; i < 3; i++)
        {
            moveObjects.transform.GetChild(i).gameObject.GetComponent<MovingObject>().Reset();
        }
    }
}
