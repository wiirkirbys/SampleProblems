using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingObject : MonoBehaviour
{
    public MovingObjectData data;
    public GameObject thisObject;
    bool isPaused;
    // Start is called before the first frame update
    void Start()
    {
        thisObject.transform.position = data.initialLocation;
        thisObject.transform.rotation = data.initialDirection;
        thisObject.GetComponent<Rigidbody>().velocity = thisObject.transform.forward * data.initialSpeed; //moves forward
        isPaused = false;
    }

    // Update is called once per frame
    void Update()
    {
        data.location = thisObject.transform.position;
        data.direction = thisObject.transform.rotation;
        data.speed = thisObject.GetComponent<Rigidbody>().velocity.magnitude;
    }
    public void Pause()
    {
        thisObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
        isPaused = true;
    }
    public void Resume()
    {
        thisObject.GetComponent<Rigidbody>().velocity = thisObject.transform.forward * data.speed;
        isPaused = false;
    }
    public void Reset()
    {
        Start();
    }
}
