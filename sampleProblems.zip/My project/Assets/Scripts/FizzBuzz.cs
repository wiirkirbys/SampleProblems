using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class FizzBuzz : MonoBehaviour
{
    public Text outputText;


    [SerializeField]
    private int x;
    [SerializeField]
    private int y;
    [SerializeField]
    private int FrameDelay;

    private int n;
    private int frames;
    // Start is called before the first frame update
    void Start()
    {
        n = 0;
        frames = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if(frames >= FrameDelay) //triggers every FrameDelay frames
        {
            frames = 0;
            n++;
            bool FizzBuzz = false;
            string result = "";
            if(n % x == 0)
            {
                FizzBuzz = true;
                result += "Fizz";
            }
            if (n % y == 0)
            {
                FizzBuzz = true;
                result += "Buzz";
            }
            string output = "FizzBuzz result: " + n.ToString() + " = ";
            if(FizzBuzz)
            {
                output += result;
            }
            else
            {
                output += n.ToString();
            }
            outputText.text = output;
        }
        frames++;
    }
}
