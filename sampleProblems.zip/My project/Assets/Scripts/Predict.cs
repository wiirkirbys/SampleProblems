using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Predict : MonoBehaviour
{
    //NOTE: I am aware I can make this modular by finding every instance of a given object in a scene in the start() method.
    public GameObject movingObjects;
    public GameObject indicators;

    public int predictTimeFrames;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Indicate());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    IEnumerator Indicate()
    {
        int i = 0;
        while(i < 3)
        {
            i++;
            if (i >= 3) i = 0;
            indicators.transform.GetChild(i).position = movingObjects.transform.GetChild(i).position + //indicator position = direction * speed * time
                movingObjects.transform.GetChild(i).forward * movingObjects.transform.GetChild(i).GetComponent<MovingObject>().data.speed * predictTimeFrames;
            yield return null;
        }
        
    }
}
